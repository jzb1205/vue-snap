import BYQ_ZS from "./byq/BYQ_ZS"; //变压器类
import KG_DLQ from "./kg/KG_DLQ"; //断路器类（合，分）
import KG_FHKG from "./kg/KG_FHKG"; //负荷开关（合，分）

export default {
  BYQ_ZS,
  KG_DLQ,
  KG_FHKG
};
