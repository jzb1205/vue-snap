import Terminal from "./Terminal";
import Breaker from "./Breaker";

export default {
  Terminal,
  Breaker
};
