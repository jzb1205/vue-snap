import BYQ from "./byq/BYQ";

export default {
  BYQ
};
