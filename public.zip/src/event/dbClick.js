/**
 *鼠标双击事件
 *
 * @param {*} e
 */
const dbClick = function(e) {};

export default dbClick;
