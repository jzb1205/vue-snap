import click from "./click";
import dbClick from "./dbClick";

export default {
  click,
  dbClick
};
