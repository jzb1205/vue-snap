import click from "./click";
import dbClick from "./dbClick";
import hover from "./dbClick";

export default {
  click,
  dbClick,
  hover
};
